//
//  YTimeTeller.h
//  YTimeTeller
//
//  Created by Yohannes on 5/22/23.
//

#import <Foundation/Foundation.h>

//! Project version number for YTimeTeller.
FOUNDATION_EXPORT double YTimeTellerVersionNumber;

//! Project version string for YTimeTeller.
FOUNDATION_EXPORT const unsigned char YTimeTellerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YTimeTeller/PublicHeader.h>


